package esercizi_riepilogo_febbraio;

class Quadro extends Dipendente{
	/* attributes */
	private String nome;
	private String cognome;
	private int numero_sottoposti;
	private double salario;
	
	/* constructor */
	public Quadro(String nome_in, String cognome_in, int numero_sottoposti_in, double salario_in) {
		super(nome_in, cognome_in, salario_in);
		this.numero_sottoposti = numero_sottoposti_in;
	}
	
	/*methods*/
	public void aumentaResponsabilita(int nuovi_sottoposti) {
		this.numero_sottoposti += nuovi_sottoposti;
	}
	
	public int getNumero_sottoposti() {
		return numero_sottoposti;
	}

	public void setNumero_sottoposti(int numero_sottoposti) {
		this.numero_sottoposti = numero_sottoposti;
	}
	
	
	

}
