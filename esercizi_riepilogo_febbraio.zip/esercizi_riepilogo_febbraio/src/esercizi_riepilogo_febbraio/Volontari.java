package esercizi_riepilogo_febbraio;

class Volontari extends Personale{
	/* attributi */
	
	/* constructor */
	
	

}
