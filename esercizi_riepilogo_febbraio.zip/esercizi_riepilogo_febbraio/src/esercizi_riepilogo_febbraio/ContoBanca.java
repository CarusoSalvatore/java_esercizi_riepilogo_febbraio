package esercizi_riepilogo_febbraio;

class ContoBanca {
	/* attributes */
	private double saldo;
	
	/* constructor */
	public ContoBanca(double saldo_in) throws IllegalArgumentException{
		if(saldo_in < 0) {
			throw new IllegalArgumentException("Saldo iniziale negativo non ammissibile.");
		}
		this.saldo = saldo_in;
	}

	/* methods */
	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public void prelevaSoldi(double somma_prelevata) throws IllegalArgumentException{
		if(somma_prelevata < 0) {
			throw new IllegalArgumentException("Non si pu� prelevare una somma negativa.");
		}
		else if (somma_prelevata > this.saldo) {
			throw new IllegalArgumentException("Non si dispone di tale somma.");
		}
		else {
			this.saldo = this.saldo - somma_prelevata;
			System.out.println("Si dispone di: " + this.saldo + "euro.");
		}
	}
	
	public void depositaSoldi(double somma_depositata) throws IllegalArgumentException{
		if (somma_depositata < 0) {
			throw new IllegalArgumentException("Non si pu� depositare una somma negativa.");
		}
		else {
			this.saldo = this.saldo + somma_depositata;
			System.out.println("Si dispone di: " + this.saldo + " euro.");
		}
	}
	
	public void componiInteresse(double interest, int years) throws IllegalArgumentException{
		if(interest > 1 || interest < 0) {
			throw new IllegalArgumentException("Il tasso di interesse inserito � inammissibile");
		}
		else {
			this.saldo = this.saldo + Math.pow(this.saldo*interest, years); 
		}
	}
	
		
}
	


