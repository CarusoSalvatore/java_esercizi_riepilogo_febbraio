package esercizi_riepilogo_febbraio;

class Veicolo {
	/* attributes */
	protected String targa;
	protected int n_ruote;
	
	/* constructor */
	public Veicolo(String targa_input, int n_ruote_input) {
		this.targa = targa_input;
		this.n_ruote = n_ruote_input;
	}
	
	/* methods */
	public String getTarga() {
		return targa;
	}

	public void setTarga(String targa) {
		this.targa = targa;
	}

	public int getN_ruote() {
		return n_ruote;
	}

	public void setN_ruote(int n_ruote) {
		this.n_ruote = n_ruote;
	}
	
	

}
