package esercizi_riepilogo_febbraio;

class Dipendenti extends Personale{
	/* attributes */
	private String codice_fiscale;
	private int base_paga;
	private String tipologia; //this can be: GIORNALIERO or IMPIEGATO
	private int numero_giorni;
	private String[] bonus; // this can be: "A", "B", "C"
	
	/* constructor*/
	public Dipendenti(String nome_in, String indirizzo_in, int numero_telefono_in, String codice_fiscale_in, int base_paga_in, String tipologia_in) {
		super(nome_in, indirizzo_in, numero_telefono_in);
		this.codice_fiscale = codice_fiscale_in;
		this.base_paga = base_paga_in + super.paga; 
		this.tipologia = tipologia_in;
		
	}
	
	
	/* methods */
	public String getCodice_fiscale() {
		return codice_fiscale;
	}

	public void setCodice_fiscale(String codice_fiscale) {
		this.codice_fiscale = codice_fiscale;
	}

	public int getBase_paga() {
		return base_paga;
	}

	public void setBase_paga(int base_paga) {
		this.base_paga = base_paga;
	}


	public String getTipologia() {
		return tipologia;
	}


	public void setTipologia(String tipologia) {
		this.tipologia = tipologia;
	}
	
	public void calcolaPaga() throws IllegalArgumentException {
		if (this.tipologia != "GIORNALIERO" || this.tipologia != "IMPIEGATO") {
			throw new IllegalArgumentException("Tipologia dipendende non valida!");
		}
		else {
			if(this.tipologia != "GIORNALIERO") {
				if(this.numero_giorni == 0) {
					throw new IllegalArgumentException("Nessun giorno di lavoro registrato.");
				}
				else {
					this.paga = this.base_paga*this.numero_giorni;
				}
				
			}
			else if(this.tipologia != "IMPIEGATO") {
				
				int[] bonus_counter = {0, 0, 0};
				final int value_A = 1000;
				final int value_B = 750;
				final int value_C = 200;
				
				for(int i = 0; i < this.bonus.length ; i++) {
					if(this.bonus[i] == "A") {
						bonus_counter[0] += 1;
					}
					else if(this.bonus[i] == "B") {
						bonus_counter[1] += 1;
					}
					else if(this.bonus[i] == "C") {
						bonus_counter[2] += 1;
					}
				}
				
				this.paga = this.base_paga + bonus_counter[0]*value_A + bonus_counter[1]*value_B + bonus_counter[2]*value_C;
			}
		}
	}
	
	public int getNumero_giorni() {
		return numero_giorni;
	}


	public void setNumero_giorni(int numero_giorni) {
		this.numero_giorni = numero_giorni;
	}


	public String[] getBonus() {
		return bonus;
	}


	public void setBonus(String[] bonus) {
		this.bonus = bonus;
	} 

}
