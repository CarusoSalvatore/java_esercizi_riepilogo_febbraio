package esercizi_riepilogo_febbraio;

class Triangolo {
	/* attributes */
	private double lato_1;
	private double lato_2;
	private double lato_3;
	
	/* constructor */
	public Triangolo(double lato_1_in, double lato_2_in, double lato_3_in) throws IllegalArgumentException{
		if(lato_3_in > lato_1_in + lato_2_in || lato_2_in > lato_1_in + lato_3_in || lato_1_in > lato_2_in + lato_3_in) {
			throw new IllegalArgumentException("Triangular Inequality not respected.");
		}
		this.lato_1 = lato_1_in; 
		this.lato_2 = lato_2_in;
		this.lato_3 = lato_3_in;
	}
	
	
	/* methods */
	public double getLato_1() {
		return lato_1;
	}

	public void setLato_1(double lato_1) {
		this.lato_1 = lato_1;
	}

	public double getLato_2() {
		return lato_2;
	}

	public void setLato_2(double lato_2) {
		this.lato_2 = lato_2;
	}

	public double getLato_3() {
		return lato_3;
	}

	public void setLato_3(double lato_3) {
		this.lato_3 = lato_3;
	}
	
	public double getPerimetro() {
		double perimetro = this.lato_1 + this.lato_2 + this.lato_3;
		return perimetro;
	}
	
	

}
