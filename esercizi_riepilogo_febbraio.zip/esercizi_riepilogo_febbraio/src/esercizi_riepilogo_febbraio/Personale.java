package esercizi_riepilogo_febbraio;

class Personale {
		/* attributes */
		protected String nome;
		protected String indirizzo;
		protected int numero_telefono;
		protected int paga;
		
		/* constructor */
		public Personale(String nome_in, String indirizzo_in, int numero_telefono_in) {
			this.nome = nome_in;
			this.indirizzo = indirizzo_in;
			this.numero_telefono = numero_telefono_in;
			this.paga = 0;
		}
		
		
		/* methods */
		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public String getIndirizzo() {
			return indirizzo;
		}

		public void setIndirizzo(String indirizzo) {
			this.indirizzo = indirizzo;
		}

		public int getNumero_telefono() {
			return numero_telefono;
		}

		public void setNumero_telefono(int numero_telefono) {
			this.numero_telefono = numero_telefono;
		}


		public int getPaga() {
			return paga;
		}


		public void setPaga(int paga) {
			this.paga = paga;
		}
			
	}
		


