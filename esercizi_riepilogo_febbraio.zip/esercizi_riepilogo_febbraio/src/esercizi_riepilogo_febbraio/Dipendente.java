package esercizi_riepilogo_febbraio;

public class Dipendente {
	/*attributes*/
	protected String nome;
	protected String cognome;
	private double salario;
	
	/*constructor*/
	public Dipendente(String nome_in, String cognome_in, double salario_in) {
		this.nome = nome_in;
		this.cognome = cognome_in;
		this.salario = salario_in;
		
	}
	
	/*methods*/
	/*methods*/
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	public void giveAumento(double percentuale) {
		if(percentuale > 0 && percentuale < 1) {
			this.salario = this.salario + this.salario*percentuale;
		}
		else {
			System.out.println("Percentuale non accettabile");
		} 
	}


}
