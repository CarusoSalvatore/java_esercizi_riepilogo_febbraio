package esercizi_riepilogo_febbraio;

class Autocarro extends Veicolo{
	/* attributi */
	private int max_carico;
	private int carico;
	
	/* constructor */
	public Autocarro(String targa_input, int n_ruote_input, int max_carico_input, int carico_input) {
		super(targa_input, n_ruote_input);
		this.max_carico = max_carico_input;
		this.carico = carico_input;
		
	}
	
	/* methods */
	public int getMax_carico() {
		return max_carico;
	}

	public void setMax_carico(int max_carico) {
		this.max_carico = max_carico;
	}

	public int getCarico() {
		return carico;
	}

	public void setCarico(int carico) {
		this.carico = carico;
	}
	
	public void caricaMerce(int merce) {
		if(this.carico + merce > this.max_carico) {
			System.out.println("Impossibile caricare: " + merce + " kg.\n");
			int rimanenza = this.max_carico - this.carico;
			System.out.println("Si possono caricare al massimo: " + rimanenza + " kg.\n");
		}
		else if(this.carico + merce == this.max_carico) {
			System.out.println("Massimo carico raggiunto.\n");
			this.carico = this.carico + merce;  
		}
		else {
			this.carico = this.carico + merce;
			System.out.println("Carico attuale: " + this.carico + " kg.\n");
			int rimanenza = this.max_carico - this.carico;
			System.out.println("E' possibile caricare ancora: " + rimanenza + " kg.\n");
		}
	}
	
	public void scaricaMerce(int merce) {
		if(merce <= this.carico) {
			this.carico = this.carico - merce;
			System.out.println("Carico attuale: " + this.carico + " kg.\n");
			int rimanenza = this.max_carico - this.carico;
			System.out.println("Si possono caricare ancora: " + rimanenza + " kg.\n");
		}
		else {
			System.out.println("Non puoi scaricare pi� kg di quanti non ce ne siano gi�.\n");
		}
		 
		
		
	}
	

}
