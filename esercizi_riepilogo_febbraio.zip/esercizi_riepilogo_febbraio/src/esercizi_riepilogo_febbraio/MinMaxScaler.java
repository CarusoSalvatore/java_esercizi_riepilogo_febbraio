package esercizi_riepilogo_febbraio;

import java.util.*;

class MinMaxScaler {
	/* attributes */
	private double minimo;
	private double massimo;
	
	/* constructor */
	public MinMaxScaler(ArrayList<Double> array) throws IllegalArgumentException{
		this.minimo = Collections.min(array);
		this.massimo = Collections.max(array);
		
		if(this.minimo - this.minimo == 0) {
			throw new IllegalArgumentException("Massimo meno minimo fa zero!");
		}
		
	}
	
	/* methods */
	public ArrayList<Double> min_max_scaler_Implementation(ArrayList<Double> array){
		ArrayList<Double> scaled_array = new ArrayList<Double>();
		for (int i = 0; i < array.size() ; i++) {
			scaled_array.add((array.get(i) - minimo)/(massimo - minimo));
		}
		return scaled_array;
	}

}
