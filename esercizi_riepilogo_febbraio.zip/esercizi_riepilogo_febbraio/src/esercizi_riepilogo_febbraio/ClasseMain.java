package esercizi_riepilogo_febbraio;

import java.util.*;

public class ClasseMain {
	public static void main(String[] args) {
		ArrayList<Double> array = new ArrayList<Double>();
		ArrayList<Double> array_scalato = new ArrayList<Double>();
		
		for (int i = 1; i <= 5; i++) {
			array.add(i*3.2);
		}
		
		for (int i = 1; i <= 5; i++) {
			array.add( - i*7.9);
		}
		
		for (int i = 0; i < 10; i++) {
			System.out.println(array.get(i));
		}
		
		System.out.println("*******************");
	
		MinMaxScaler scaler = new MinMaxScaler(array);
		
		array_scalato = scaler.min_max_scaler_Implementation(array);
		
		for (int i = 0; i < 10; i++) {
			System.out.println(array_scalato.get(i));
		}
		
	}

}
