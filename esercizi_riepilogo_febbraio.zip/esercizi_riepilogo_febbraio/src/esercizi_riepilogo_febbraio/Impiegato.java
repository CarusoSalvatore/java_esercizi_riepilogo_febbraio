package esercizi_riepilogo_febbraio;

class Impiegato extends Dipendente{
	/*attributi*/
	private String nome;
	private String cognome;
	private String mansione;
	private double salario;
	
	/*constructor*/
	public Impiegato(String nome_in, String cognome_in, String mansione_in, double salario_in) {
		super(nome_in, cognome_in, salario_in);
		this.mansione = mansione_in;
	}
	
	/*methods*/
	public String getMansione() {
		return mansione;
	}
	
	public void setMansione(String mansione) {
		this.mansione = mansione;
	}	

}
