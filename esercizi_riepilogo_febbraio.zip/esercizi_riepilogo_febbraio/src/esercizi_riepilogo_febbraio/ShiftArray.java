package esercizi_riepilogo_febbraio;

import java.util.*;

public class ShiftArray {
	/* attributes */
	
	/* constructor */
	public ShiftArray() {}
	
	/* methods */
	public static ArrayList<Integer> arrayShiftato(ArrayList<Integer> array) {
		ArrayList<Integer> array_shiftato = new ArrayList<Integer>();
		for(int i = 0; i < array.size()-1; i++) {
			array_shiftato.add(array.get(i + 1));
		}
		array_shiftato.add(array.get(0));
		return array_shiftato;
	}

}
